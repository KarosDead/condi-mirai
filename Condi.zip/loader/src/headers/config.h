#pragma once

#define HTTP_SERVER "43.229.150.28"
#define HTTP_PORT 80

#define TFTP_SERVER "43.229.150.28"
